const STORAGE_KEY = "outingPortalRequestsV1";
const form = document.getElementById("outingForm");
const rows = document.getElementById("requestRows");
const emptyState = document.getElementById("emptyState");
const toast = document.getElementById("toast");
let requests = loadRequests();

function loadRequests() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { return []; }
}
function saveRequests() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(requests));
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[char]);
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 2600);
}
function render() {
  document.getElementById("totalCount").textContent = requests.length;
  document.getElementById("pendingCount").textContent = requests.filter(r => r.status === "Pending").length;
  document.getElementById("approvedCount").textContent = requests.filter(r => r.status === "Approved").length;
  document.getElementById("rejectedCount").textContent = requests.filter(r => r.status === "Rejected").length;
  rows.innerHTML = "";
  emptyState.hidden = requests.length > 0;
  requests.slice().reverse().forEach(request => {
    const tr = document.createElement("tr");
    const dateText = new Date(`${request.date}T00:00:00`).toLocaleDateString(undefined, {day:"numeric", month:"short", year:"numeric"});
    tr.innerHTML = `
      <td><strong>${escapeHTML(request.student)}</strong><small>${escapeHTML(request.regno)}</small></td>
      <td>${escapeHTML(request.destination)}<small>${escapeHTML(request.reason)}</small></td>
      <td>${escapeHTML(dateText)}<small>${escapeHTML(request.departure)} – ${escapeHTML(request.returnTime)}</small></td>
      <td><span class="status status-${request.status}">${request.status}</span></td>
      <td><select class="action-select" aria-label="Demo status for ${escapeHTML(request.student)}" data-status-id="${request.id}">
        <option ${request.status === "Pending" ? "selected" : ""}>Pending</option>
        <option ${request.status === "Approved" ? "selected" : ""}>Approved</option>
        <option ${request.status === "Rejected" ? "selected" : ""}>Rejected</option>
      </select><button class="delete-btn" type="button" data-delete-id="${request.id}">Delete</button></td>`;
    rows.appendChild(tr);
  });
}
form.addEventListener("submit", event => {
  event.preventDefault();
  const data = new FormData(form);
  const date = data.get("date");
  const departure = data.get("departure");
  const returnTime = data.get("returnTime");
  if (returnTime <= departure) {
    showToast("Return time should be later than departure time.");
    return;
  }
  requests.push({
    id: (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()),
    student: data.get("student").trim(),
    regno: data.get("regno").trim(),
    destination: data.get("destination").trim(),
    reason: data.get("reason").trim(),
    date, departure, returnTime,
    phone: data.get("phone").trim(),
    status: "Pending"
  });
  saveRequests();
  render();
  form.reset();
  showToast("Demo request submitted successfully.");
  document.getElementById("requests").scrollIntoView({behavior:"smooth", block:"start"});
});
rows.addEventListener("change", event => {
  const id = event.target.dataset.statusId;
  if (!id) return;
  const request = requests.find(r => r.id === id);
  if (request) {
    request.status = event.target.value;
    saveRequests();
    render();
    showToast("Demo status updated.");
  }
});
rows.addEventListener("click", event => {
  const id = event.target.dataset.deleteId;
  if (!id) return;
  requests = requests.filter(request => request.id !== id);
  saveRequests();
  render();
  showToast("Request removed from this browser.");
});
document.getElementById("clearButton").addEventListener("click", () => {
  if (!requests.length) { showToast("There is no demo data to clear."); return; }
  if (window.confirm("Clear all outing requests saved in this browser?")) {
    requests = [];
    saveRequests();
    render();
    showToast("Demo data cleared.");
  }
});
const dateInput = form.elements.date;
const today = new Date();
dateInput.min = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;
render();
