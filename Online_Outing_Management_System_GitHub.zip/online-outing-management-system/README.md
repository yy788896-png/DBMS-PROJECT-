# Online Outing Management System

A responsive front-end demo for a college outing-permission workflow. Created as a student project starter for **Yashwant S P** at **KIT Kalaignar Karunanidhi Institute of Technology**.

## Live demo with GitHub Pages

1. Sign in to GitHub and create a **new public repository** (for example, `online-outing-management-system`).
2. Extract this ZIP file on your computer.
3. Upload the files and folders **inside** the extracted project folder to the repository root. Make sure `index.html`, `style.css`, and `script.js` are at the root.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/(root)`, then click **Save**.
7. Wait a few minutes and open the published URL shown on the Pages settings screen. It will normally look like `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Features

- Responsive dashboard and outing request form
- Required-field validation and time validation
- Request counts for total, pending, approved, and rejected
- Demo status changes and delete action
- Browser-local storage for demonstration
- No external libraries or build step required

## Important limitations

This is a **front-end demonstration**, not a production-ready college permission system. Requests and status changes are stored in the current browser using `localStorage`; they are not shared with a warden, another device, or a central database. The status selector is included to demonstrate the workflow and must not be treated as an actual approval.

For a real deployment, add a Java backend (for example, Spring Boot or a servlet application), a database such as MySQL, server-side authentication and role-based authorization, secure password hashing, input validation, and HTTPS. GitHub Pages hosts static files only; it does not run Java server code or MySQL.

## Project files

- `index.html` — page structure and forms
- `style.css` — responsive visual design
- `script.js` — form validation and browser-local demo storage
- `LICENSE` — MIT license
